extern double media(double,double);
