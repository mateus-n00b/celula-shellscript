#include <stdio.h>
double media(double a, double b){
  return (a+b)/2;
}
