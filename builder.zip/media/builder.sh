#!/bin/bash
export CPATH=/tmp/include
export LIBRARY_PATH=/tmp/lib
export LD_LIBRARY_PATH=/tmp/lib

if [ $# -ne 1 ]
then
  echo "Usage: $0 <file.c>"
  exit
fi
mkdir /tmp/lib /tmp/include /tmp/bin &> /dev/null

my_file=$(cut -f1 -d. <<< "$1")
gcc -c -Wall -Werror -fpic "$1"
gcc -shared -o lib"$my_file".so "$my_file".o
gcc "main.c" -o main -l"$my_file"
echo "alias 'main'='LD_LIBRARY_PATH=/tmp/lib /tmp/bin/main'" >> ~/.profile
mv main "/tmp/bin"
mv $my_file.h "/tmp/include"
mv lib"$my_file".so "/tmp/lib"
. ~/.profile
