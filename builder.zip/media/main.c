#include <stdio.h>
#include "media.h"
int main(int argc, char* argv[]) {
  double v1, v2, m;
  v1 = 5.2;
  v2 = 7.9;
  m = media(v1, v2);
  printf("%3.2f %3.2f %3.2f\n", v1, v2, m);
return 0;
}
